export const colors = {
  primary: 'var(--color-primary)',
  red: '#d82c23',
};

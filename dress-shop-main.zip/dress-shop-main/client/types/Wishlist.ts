import { Product } from 'types';

export interface WishlistItem {
  _id: string;
  product: Product;
}

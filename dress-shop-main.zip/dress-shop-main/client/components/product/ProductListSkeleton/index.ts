export { default } from './ProductListSkeleton';

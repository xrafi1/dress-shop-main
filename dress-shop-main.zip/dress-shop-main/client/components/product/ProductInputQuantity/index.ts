export { default } from './ProductInputQuantity';

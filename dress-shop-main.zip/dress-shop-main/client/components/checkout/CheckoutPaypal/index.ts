export { default } from './CheckoutPaypal';

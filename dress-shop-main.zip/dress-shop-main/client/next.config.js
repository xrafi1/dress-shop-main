module.exports = {
  images: {
    domains: ['res.cloudinary.com', 'lh3.googleusercontent.com'],
  },
};

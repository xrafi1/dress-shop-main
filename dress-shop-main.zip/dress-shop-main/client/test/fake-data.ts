import { cartItemGenerator } from './data-generators';

export const fakeCartItems = [cartItemGenerator(), cartItemGenerator(), cartItemGenerator()];

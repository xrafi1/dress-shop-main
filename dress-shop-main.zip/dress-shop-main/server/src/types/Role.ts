export enum Role {
  User = 'user',
  Admin = 'admin',
}

export type Banner = {
  _id: string;
  name: string;
  imageURL: string;
};

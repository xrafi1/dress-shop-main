export { default as ChangePassword } from './ChangePassword';
export { default as EditProfile } from './EditProfile';
